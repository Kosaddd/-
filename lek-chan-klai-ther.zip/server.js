
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = new Server(server);

const rooms = {};

app.use(express.static('public'));

io.on('connection', (socket) => {
    socket.on('create-room', (roomCode, username) => {
        socket.join(roomCode);
        if (!rooms[roomCode]) {
            rooms[roomCode] = {};
        }
        rooms[roomCode][socket.id] = { username, score: 10, number: null };
        io.to(roomCode).emit('update-players', rooms[roomCode]);
    });

    socket.on('submit-number', ({ roomCode, number }) => {
        if (rooms[roomCode] && rooms[roomCode][socket.id]) {
            rooms[roomCode][socket.id].number = number;
            const players = rooms[roomCode];
            const allSubmitted = Object.values(players).every(p => p.number !== null);
            if (allSubmitted) {
                const values = Object.values(players).map(p => p.number);
                const avg = values.reduce((a, b) => a + b, 0) / values.length;
                const target = avg * 0.8;
                let winnerId = null;
                let closestDiff = Infinity;
                for (const [id, player] of Object.entries(players)) {
                    const diff = Math.abs(player.number - target);
                    if (diff < closestDiff) {
                        closestDiff = diff;
                        winnerId = id;
                    }
                }
                for (const [id, player] of Object.entries(players)) {
                    if (id !== winnerId) {
                        player.score -= 1;
                    }
                    player.number = null;
                }
                for (const id in players) {
                    if (players[id].score <= 0) {
                        delete players[id];
                        io.to(roomCode).emit('player-eliminated', id);
                    }
                }
                io.to(roomCode).emit('round-result', { players, target });
            }
        }
    });

    socket.on('disconnect', () => {
        for (const roomCode in rooms) {
            if (rooms[roomCode][socket.id]) {
                delete rooms[roomCode][socket.id];
                io.to(roomCode).emit('update-players', rooms[roomCode]);
            }
        }
    });
});

server.listen(process.env.PORT || 3000, () => {
    console.log('Server is running');
});
